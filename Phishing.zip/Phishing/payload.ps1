# Affiche un message d'alerte sur la sensibilisation
$message = "SIMULATION DE PHISHING - Votre organisation teste vos réflexes de sécurité.
Si vous voyez ce message, vous avez cliqué sur un lien potentiellement dangereux.
Contactez immédiatement votre service informatique."
Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show($message, "Alerte de sécurité", "OK", "Warning")
